// Variável global para armazenar os gráficos atuais
var graficos = {};
var graficoAbertoParaMes;

// Mapeamento de meses para cores específicas
var coresPorMes = {
    'Janeiro': 'rgb(255, 99, 132)',
    'Fevereiro': 'rgb(54, 162, 235)',
    'Março': 'rgb(255, 206, 86)',
    'Abril': 'rgb(75, 192, 192)',
    'Maio': 'rgb(153, 102, 255)',
    'Junho': 'rgb(255, 159, 64)',
    'Julho': 'rgb(255, 99, 132)',
    'Agosto': 'rgb(54, 162, 235)',
    'Setembro': 'rgb(255, 206, 86)',
    'Outubro': 'rgb(75, 192, 192)',
    'Novembro': 'rgb(153, 102, 255)',
    'Dezembro': 'rgb(255, 159, 64)'
};

// Função para obter a cor do mês
function getCorPorMes(mes) {
    // Verifica se o mês está mapeado para uma cor específica
    if (coresPorMes.hasOwnProperty(mes)) {
        return coresPorMes[mes];
    } else {
        // Retorna uma cor padrão se o mês não tiver uma cor específica
        return 'rgb(0, 0, 0)';
    }
}

// Função para mostrar ou fechar o gráfico correspondente ao mês
function mostrarGrafico(mes) {
    if (graficoAbertoParaMes === mes) {
        fecharGrafico();
        return;
    }

    var dadosDoMes = obterDadosDoMes(mes); // Função para obter os dados do mês

    // Destruir o gráfico anterior antes de criar um novo
    fecharGrafico();

    // Configuração do gráfico
    var ctx = document.getElementById('graficoCanvas').getContext('2d');
    graficos[mes] = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: dadosDoMes.rotulos,
            datasets: [{
                label: 'Doações de:',
                data: dadosDoMes.dados,
                backgroundColor: getCorPorMes(mes), // Usa a cor específica para o mês
                borderColor: '#000000', // Cor da borda das barras
                borderWidth: 1
            }]
        },
        options: {
            scales: {
                yAxes: [{
                    ticks: {
                        beginAtZero: true
                    }
                }]
            },
            legend: {
                display: false // Ocultando a legenda do gráfico
            },
            responsive: false // Desativando a responsividade do gráfico
        }
    });

    document.getElementById('nomeMes').textContent = mes; // Define o texto do elemento p como o mês correspondente

    graficoAbertoParaMes = mes;
}

// Função para fechar o gráfico
function fecharGrafico() {
    if (graficos[graficoAbertoParaMes]) {
        graficos[graficoAbertoParaMes].destroy();
        delete graficos[graficoAbertoParaMes];
        graficoAbertoParaMes = null;

        // Remova o nome do mês quando o gráfico é fechado
        document.getElementById('nomeMes').textContent = '';
    }
}

// Função para obter os dados do mês selecionado (exemplo de dados fictícios)
function obterDadosDoMes(mes) {
    var rotulos = ['Ração', 'Vacinas', 'Brinquedos', 'Areia', 'Dinheiro']; // Exemplo de rótulos para os dias
    var dados = []; // Exemplo de dados para as vendas em cada dia

    // Dados fictícios para os meses de exemplo
    switch(mes) {
        case 'Janeiro':
            dados = [10, 20, 15, 25, 30];
            break;
        case 'Fevereiro':
            dados = [8, 18, 12, 22, 28];
            break;
        case 'Março':
            dados = [12, 22, 18, 13, 31];
            break;
        case 'Abril':
            dados = [15, 24, 14, 8, 22];
            break;
        case 'Maio':
            dados = [17, 17, 12, 23, 33];
            break;
        case 'Junho':
            dados = [20, 22, 10, 10, 14];
            break;
        case 'Julho':
            dados = [19, 23, 7, 15, 34];
            break;
        case 'Agosto':
            dados = [13, 26, 10, 23, 28];
            break;
        case 'Setembro':
            dados = [8, 25, 12, 25, 16];
            break;
        case 'Outubro':
            dados = [9, 27, 10, 12, 23];
            break;
        case 'Novembro':
            dados = [14, 24, 8, 10, 12];
            break;
        case 'Dezembro':
            dados = [11, 22, 11, 28, 15];
            break;
        default:
            dados = [0, 0, 0, 0, 0];
    }

    return { rotulos: rotulos, dados: dados };
}